--[[ script.on_event(defines.events.on_player_driving_changed_state, function(event)
    
    local player = game.get_player(event.player_index) --Get player from event
    if(event.entity.type == "car") then --Test if car is valid
        if player.vehicle == nil then --This tests whether the player is entering or exiting the car, since on_player_driving_changed_state does both
            local car = event.entity --Get car from event
            local car_pos = {x=car.position.x, y=car.position.y + 5 }
            local exit_pos = player.surface.find_non_colliding_position("character", car_pos, 2, 0.2, false) --Find valid exit position at car's shadow
            if car.name == "hover-car" or car.name == "hover-car-mk2" then --Make sure this is a hover car
                    if exit_pos ~= nil then --If exit position is valid
                        player.teleport(exit_pos) --Teleport the player to the exit position
                    else --If not, teleport the player to the car's position and force the player into the car
                        player.teleport(car.position)
                        player.driving = true
                        player.print("forced into car")
                        player.print("Cannot exit here, location is blocked.")
                        do return end
                    end
            end
        end
    end
end) ]]

-- old control.lua ^^^

script.on_event(defines.events.on_player_driving_changed_state, function(event)

    if game.permissions.get_group("driving-lock") == nil then
        game.permissions.create_group("driving-lock")
        game.permissions.get_group("driving-lock").set_allows_action(defines.input_action.toggle_driving, false)
    end

    local player = game.get_player(event.player_index) --Get player from event
    local drivingLock = game.permissions.get_group("driving-lock")
    if(event.entity ~= nil) then --Make sure car is a valid entity / crash prevention (bug report)
        if(event.entity.type == "car") then --Test if car is valid
            if player.vehicle ~= nil then --This tests whether the player is entering or exiting the car, since on_player_driving_changed_state does both
                local car = event.entity --Get car from event
                if car.name == "hover-car" or car.name == "hover-car-mk2" then --Make sure this is a hover car
                    drivingLock.add_player(player)
                end
            end
            if player.vehicle == nil then --This tests whether the player is entering or exiting the car, since on_player_driving_changed_state does both
                local car = event.entity --Get car from event
                if car.name == "hover-car" or car.name == "hover-car-mk2" then --Make sure this is a hover car
                    drivingLock.remove_player(player)
                end
            end
        end
    elseif(event.entity == nil) then --If car isnt valid, remove driving-lock just incase (bug report)
        drivingLock.remove_player(player)
    end
end)

script.on_event("input_hover-car-exit", function(event)
    local player = game.get_player(event.player_index)
    if player.vehicle ~= nil then --Player is in car
        local car = player.vehicle
        if car.name == "hover-car" or car.name == "hover-car-mk2" then --Make sure this is a hover car
            local car_pos = {x=car.position.x, y=car.position.y + 5 }
            local exit_pos = player.surface.find_non_colliding_position("character", car_pos, 2, 0.2, false) --Find valid exit position at car's shadow
            if exit_pos ~= nil then
                if(car.get_driver() == player.character or (car.get_driver() and (player.character == nil and player.connected))) then --If driver exists
                    car.set_driver(nil) --Remove driver
                end
                if(car.get_passenger() == player.character or (car.get_passenger() and (player.character == nil and player.connected))) then --If passenger exists
                    car.set_passenger(nil) --Remove passenger
                end
                player.teleport(exit_pos) --Teleport to exit position near shadow
            else
                player.print("Cannot exit here, location is blocked.")
            end
        end
    else --Player is not in car, check if nearby hover car
        local nearbyCars = player.surface.find_entities_filtered{position = player.position, radius = 2.5, name = {"hover-car", "hover-car-mk2"}}
        if(next(nearbyCars)) then
            local nearby = player.surface.get_closest(player.position, nearbyCars) --Get closest hover car in range
            local car_pos = player.surface.find_non_colliding_position("car", nearby.position, 0.1, 0.01, false)
            if(car_pos == nil) then --Car is ontop of another entity
                if(nearby.get_driver() ~= nil) then --If driver exists
                    if(nearby.get_passenger() == nil) then --If passenger DOESNT exists
                        nearby.set_passenger(player.character)
                    end
                else
                    nearby.set_driver(player.character)
                end
            end
        end
    end
end)