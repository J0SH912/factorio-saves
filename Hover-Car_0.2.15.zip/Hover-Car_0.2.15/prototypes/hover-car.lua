local hoverCar = table.deepcopy(data.raw.car["car"])
hoverCar.name = "hover-car"
--[[ hoverCar.icons = {
    {
        icon = hoverCar.icon,
        tint = {r=0.75,g=0.75,b=1,a=1}
    },
}
hoverCar.icon = "" ]]
hoverCar.icon = "__Hover-Car__/graphics/icons/hover-car-icon.png"
hoverCar.icon_size = 128
hoverCar.max_health = 200
hoverCar.collision_box = {{0,0}, {0,0}}
hoverCar.selection_box = {{-1.0,-1.0}, {1.0,1.0}}
hoverCar.drawing_box = {{-5.0,-5.0}, {5.0,5.0}}
hoverCar.sticker_box = {{-1.0,-1.0}, {1.0,1.0}}
hoverCar.selection_priority = 100
hoverCar.inventory_size = 20
hoverCar.immune_to_tree_impacts = true
hoverCar.has_belt_immunity = true
hoverCar.consumption_modifier = 1.5
hoverCar.burner = {
  effectivity = 1,
  fuel_category = "chemical",
  fuel_inventory_size = 1,
  smoke = {
    {
      deviation = {
        0.25,
        0.25
      },
      frequency = 200,
      name = "car-smoke",
      position = {
        0,
        1.5
      },
      starting_frame = 0,
      starting_frame_deviation = 60
    }
  },
  render_no_power_icon = true
}
hoverCar.render_layer = "air-object"
hoverCar.collision_mask = {"not-colliding-with-itself"}
hoverCar.guns = {}
hoverCar.flags = { "placeable-neutral", "player-creation", "not-flammable", "no-automated-item-removal", "no-automated-item-insertion" }
hoverCar.water_reflection = nil
hoverCar.sound_no_fuel = {
    {
      filename = "__base__/sound/fight/car-no-fuel-1.ogg",
      volume = 0.6
    }
}
hoverCar.working_sound = {
  sound =
  {
    filename = "__base__/sound/car-engine.ogg",
    volume = 0.6
  },
--[[   sound =
  {
    filename = "__base__/sound/steam-engine-90bpm.ogg",
    volume = 0.75
  }, ]]
  activate_sound =
  {
    filename = "__base__/sound/car-engine-start.ogg",
    volume = 0.6
  },
  deactivate_sound =
  {
    filename = "__base__/sound/car-engine-stop.ogg",
    volume = 0.6
  },
  match_speed_to_activity = true
}
hoverCar.stop_trigger = {
  {
    type = "play-sound",
    sound =
    {
      {
        filename = "__base__/sound/car-breaks.ogg",
        volume = 0.0
      }
    }
  }
}
hoverCar.minable = {hardness = 0.2, mining_time = 0.5, result = "hover-car-item"}

hoverCar.animation =
{
  layers =
  {
    {
      priority = "low",
      width = 102,
      height = 86,
      frame_count = 2,
      direction_count = 64,
      shift = {0, -0.1875},
      animation_speed = 8,
      max_advance = 0.2,
      stripes =
      {
        {
         filename = "__base__/graphics/entity/car/car-1.png",
         width_in_frames = 2,
         height_in_frames = 22
        },
        {
         filename = "__base__/graphics/entity/car/car-2.png",
         width_in_frames = 2,
         height_in_frames = 22
        },
        {
         filename = "__base__/graphics/entity/car/car-3.png",
         width_in_frames = 2,
         height_in_frames = 20
        }
      },
      hr_version =
      {
        priority = "low",
        width = 201,
        height = 172,
        frame_count = 2,
        scale = 0.5,
        direction_count = 64,
        shift = util.by_pixel(0+2, -11.5+8.5),
        animation_speed = 8,
        max_advance = 0.2,
        stripes =
        {
          {
            filename = "__base__/graphics/entity/car/hr-car-1.png",
            width_in_frames = 2,
            height_in_frames = 11
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-2.png",
            width_in_frames = 2,
            height_in_frames = 11
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-3.png",
            width_in_frames = 2,
            height_in_frames = 11
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-4.png",
            width_in_frames = 2,
            height_in_frames = 11
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-5.png",
            width_in_frames = 2,
            height_in_frames = 11
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-6.png",
            width_in_frames = 2,
            height_in_frames = 9
          }
        }
      }
    },
    {
      priority = "low",
      width = 100,
      height = 75,
      frame_count = 2,
      apply_runtime_tint = true,
      direction_count = 64,
      max_advance = 0.2,
      line_length = 2,
      shift = {0, -0.171875},
      stripes = util.multiplystripes(2,
      {
        {
          filename = "__base__/graphics/entity/car/car-mask-1.png",
          width_in_frames = 1,
          height_in_frames = 22
        },
        {
          filename = "__base__/graphics/entity/car/car-mask-2.png",
          width_in_frames = 1,
          height_in_frames = 22
        },
        {
          filename = "__base__/graphics/entity/car/car-mask-3.png",
          width_in_frames = 1,
          height_in_frames = 20
        }
      }),
      hr_version =
      {
        priority = "low",
        width = 199,
        height = 147,
        frame_count = 2,
        apply_runtime_tint = true,
        scale = 0.5,
        axially_symmetrical = false,
        direction_count = 64,
        max_advance = 0.2,
        shift = util.by_pixel(0+2, -11+8.5),
        line_length = 1,
        stripes = util.multiplystripes(2,
        {
          {
            filename = "__base__/graphics/entity/car/hr-car-mask-1.png",
            width_in_frames = 1,
            height_in_frames = 13
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-mask-2.png",
            width_in_frames = 1,
            height_in_frames = 13
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-mask-3.png",
            width_in_frames = 1,
            height_in_frames = 13
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-mask-4.png",
            width_in_frames = 1,
            height_in_frames = 13
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-mask-5.png",
            width_in_frames = 1,
            height_in_frames = 12
          }
        })
      }
    },
    {
      priority = "high",
      width = 114,
      height = 76,
      frame_count = 2,
      draw_as_shadow = true,
      direction_count = 64,
      shift = {0.28125, 5.0},
      max_advance = 0.2,
      stripes = util.multiplystripes(2,
      {
       {
        filename = "__base__/graphics/entity/car/car-shadow-1.png",
        width_in_frames = 1,
        height_in_frames = 22
       },
       {
        filename = "__base__/graphics/entity/car/car-shadow-2.png",
        width_in_frames = 1,
        height_in_frames = 22
       },
       {
        filename = "__base__/graphics/entity/car/car-shadow-3.png",
        width_in_frames = 1,
        height_in_frames = 20
       }
      })
    }
  }
}

hoverCar.turret_animation = nil

local hoverCarItem = table.deepcopy(data.raw["item-with-entity-data"]["car"])
hoverCarItem.name = "hover-car-item"
hoverCarItem.icon = "__Hover-Car__/graphics/icons/hover-car.png"
hoverCarItem.icon_size = 128
hoverCarItem.place_result = "hover-car"

local hoverCarRecipe = table.deepcopy(data.raw.recipe["car"])
hoverCarRecipe.enabled = false
hoverCarRecipe.icon = "__Hover-Car__/graphics/icons/hover-car.png"
hoverCarRecipe.icon_size = 128
hoverCarRecipe.name = "hover-car-recipe"
hoverCarRecipe.energy_required = 16
hoverCarRecipe.ingredients = {
    {"engine-unit",32},
    {"iron-plate",60},
    {"steel-plate",20},
    {"advanced-circuit",50}
}
hoverCarRecipe.result = "hover-car-item"

data:extend{

    {
        effects = {
            {
            recipe = "hover-car-recipe",
            type = "unlock-recipe"
            }
        },
        icon = "__Hover-Car__/graphics/icons/hover-car.png",
        icon_size = 128,
        name = "hoverCar",
        
        prerequisites = {
            "robotics",
            "chemical-science-pack"
        },
        type = "technology",
        unit = {
            count = 100,
            ingredients = {
                {
                    "automation-science-pack",
                    1
                  },
                  {
                    "logistic-science-pack",
                    1
                  },
                  {
                    "chemical-science-pack",
                    1
                  }
            },
            time = 30
       },
    },

    hoverCar,
    hoverCarItem,
    hoverCarRecipe

    
}