local hoverCarMK2 = table.deepcopy(data.raw.car["car"])
hoverCarMK2.name = "hover-car-mk2"
--[[ hoverCarMK2.icons = {
    {
        icon = hoverCarMK2.icon,
        tint = {r=0.75,g=1,b=0.75,a=1}
    },
} ]]
hoverCarMK2.icon = "__Hover-Car__/graphics/icons/hover-car-mk2-icon.png"
hoverCarMK2.icon_size = 128
hoverCarMK2.max_health = 500
hoverCarMK2.collision_box = {{0,0}, {0,0}}
hoverCarMK2.selection_box = {{-1.0,-1.0}, {1.0,1.0}}
hoverCarMK2.drawing_box = {{-5.0,-5.0}, {5.0,5.0}}
hoverCarMK2.sticker_box = {{-1.0,-1.0}, {1.0,1.0}}
hoverCarMK2.selection_priority = 100
hoverCarMK2.inventory_size = 40
hoverCarMK2.immune_to_tree_impacts = true
hoverCarMK2.has_belt_immunity = true
hoverCarMK2.effectivity = 1.25
hoverCarMK2.braking_power = "800kW"
--hoverCarMK2.consumption = 0.75
hoverCarMK2.burner = {
  effectivity = 1,
  fuel_category = "chemical",
  fuel_inventory_size = 2,
  smoke = {
    {
      deviation = {
        0.25,
        0.25
      },
      frequency = 200,
      name = "car-smoke",
      position = {
        0,
        1.5
      },
      starting_frame = 0,
      starting_frame_deviation = 60
    }
  },
  render_no_power_icon = true
}
hoverCarMK2.render_layer = "air-object"
hoverCarMK2.collision_mask = {"not-colliding-with-itself"}
--hoverCarMK2.guns = {}
hoverCarMK2.flags = { "placeable-neutral", "player-creation", "not-flammable", "no-automated-item-removal", "no-automated-item-insertion" }
hoverCarMK2.water_reflection = nil
hoverCarMK2.sound_no_fuel = {
    {
      filename = "__base__/sound/fight/car-no-fuel-1.ogg",
      volume = 0.6
    }
}
hoverCarMK2.working_sound =
{
  sound =
  {
    filename = "__base__/sound/car-engine.ogg",
    volume = 0.6
  },
--[[   sound =
  {
    filename = "__base__/sound/steam-engine-90bpm.ogg",
    volume = 0.75
  }, ]]
--[[   sound = {
    variations = {
      {
        filename = "__base__/sound/car-engine.ogg",
        volume = 0.6
      },
      {
        filename = "__base__/sound/steam-engine-90bpm.ogg",
        volume = 0.75
      }
    }
  }, ]]
  activate_sound =
  {
    filename = "__base__/sound/car-engine-start.ogg",
    volume = 0.6
  },
  deactivate_sound =
  {
    filename = "__base__/sound/car-engine-stop.ogg",
    volume = 0.6
  },
  match_speed_to_activity = true
}
hoverCarMK2.stop_trigger = {
  {
    type = "play-sound",
    sound =
    {
      {
        filename = "__base__/sound/car-breaks.ogg",
        volume = 0.0
      }
    }
  }
}
hoverCarMK2.minable = {hardness = 0.2, mining_time = 0.5, result = "hover-car-mk2-item"}

hoverCarMK2.animation =
{
  layers =
  {
    {
      scale = 0.6,
    
      priority = "low",
      width = 102,
      height = 86,
      frame_count = 2,
      direction_count = 64,
      shift = {0, -0.1875},
      animation_speed = 8,
      max_advance = 0.2,
      stripes =
      {
        {
         filename = "__base__/graphics/entity/car/car-1.png",
         width_in_frames = 2,
         height_in_frames = 22
        },
        {
         filename = "__base__/graphics/entity/car/car-2.png",
         width_in_frames = 2,
         height_in_frames = 22
        },
        {
         filename = "__base__/graphics/entity/car/car-3.png",
         width_in_frames = 2,
         height_in_frames = 20
        }
      },
      hr_version =
      {
        priority = "low",
        width = 201,
        height = 172,
        frame_count = 2,
        scale = 0.6,
        direction_count = 64,
        shift = util.by_pixel(0+2, -11.5+8.5),
        animation_speed = 8,
        max_advance = 0.2,
        stripes =
        {
          {
            filename = "__base__/graphics/entity/car/hr-car-1.png",
            width_in_frames = 2,
            height_in_frames = 11
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-2.png",
            width_in_frames = 2,
            height_in_frames = 11
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-3.png",
            width_in_frames = 2,
            height_in_frames = 11
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-4.png",
            width_in_frames = 2,
            height_in_frames = 11
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-5.png",
            width_in_frames = 2,
            height_in_frames = 11
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-6.png",
            width_in_frames = 2,
            height_in_frames = 9
          }
        }
      }
    },
    {
      scale = 0.6,

      priority = "low",
      width = 100,
      height = 75,
      frame_count = 2,
      apply_runtime_tint = true,
      direction_count = 64,
      max_advance = 0.2,
      line_length = 2,
      shift = {0, -0.171875},
      stripes = util.multiplystripes(2,
      {
        {
          filename = "__base__/graphics/entity/car/car-mask-1.png",
          width_in_frames = 1,
          height_in_frames = 22
        },
        {
          filename = "__base__/graphics/entity/car/car-mask-2.png",
          width_in_frames = 1,
          height_in_frames = 22
        },
        {
          filename = "__base__/graphics/entity/car/car-mask-3.png",
          width_in_frames = 1,
          height_in_frames = 20
        }
      }),
      hr_version =
      {
        priority = "low",
        width = 199,
        height = 147,
        frame_count = 2,
        apply_runtime_tint = true,
        scale = 0.6,
        axially_symmetrical = false,
        direction_count = 64,
        max_advance = 0.2,
        shift = util.by_pixel(0+2, -11+8.5),
        line_length = 1,
        stripes = util.multiplystripes(2,
        {
          {
            filename = "__base__/graphics/entity/car/hr-car-mask-1.png",
            width_in_frames = 1,
            height_in_frames = 13
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-mask-2.png",
            width_in_frames = 1,
            height_in_frames = 13
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-mask-3.png",
            width_in_frames = 1,
            height_in_frames = 13
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-mask-4.png",
            width_in_frames = 1,
            height_in_frames = 13
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-mask-5.png",
            width_in_frames = 1,
            height_in_frames = 12
          }
        })
      }
    },
    {
      scale = 1.25,

      priority = "high",
      width = 114,
      height = 76,
      frame_count = 2,
      draw_as_shadow = true,
      direction_count = 64,
      shift = {0.28125, 5.0},
      max_advance = 0.2,
      stripes = util.multiplystripes(2,
      {
       {
        filename = "__base__/graphics/entity/car/car-shadow-1.png",
        width_in_frames = 1,
        height_in_frames = 22
       },
       {
        filename = "__base__/graphics/entity/car/car-shadow-2.png",
        width_in_frames = 1,
        height_in_frames = 22
       },
       {
        filename = "__base__/graphics/entity/car/car-shadow-3.png",
        width_in_frames = 1,
        height_in_frames = 20
       }
      })
    }
  }
}

hoverCarMK2.turret_animation = {
  layers = {
    {
      animation_speed = 8,
      direction_count = 64,
      filename = "__base__/graphics/entity/car/car-turret.png",
      frame_count = 1,
      height = 29,
      hr_version = {
        animation_speed = 8,
        axially_symmetrical = false,
        direction_count = 64,
        frame_count = 1,
        height = 57,
        priority = "low",
        scale = 0.6,
        shift = {
          0.0625,
          -0.78125
        },
        stripes = {
          {
            filename = "__base__/graphics/entity/car/hr-car-turret-1.png",
            height_in_frames = 32,
            width_in_frames = 1
          },
          {
            filename = "__base__/graphics/entity/car/hr-car-turret-2.png",
            height_in_frames = 32,
            width_in_frames = 1
          }
        },
        width = 71
      },
      line_length = 8,
      priority = "low",
      shift = {0.03125, -0.890625},
      width = 36
    },
    {
      direction_count = 64,
      draw_as_shadow = true,
      filename = "__base__/graphics/entity/car/car-turret-shadow.png",
      frame_count = 1,
      height = 31,
      line_length = 8,
      priority = "low",
      shift = {
        0.875,
        5.0
      },
      width = 46
    }
  }
}

local hoverCarMK2Item = table.deepcopy(data.raw["item-with-entity-data"]["car"])
hoverCarMK2Item.name = "hover-car-mk2-item"
hoverCarMK2Item.icon = "__Hover-Car__/graphics/icons/hover-car-mk2.png"
hoverCarMK2Item.icon_size = 128
hoverCarMK2Item.place_result = "hover-car-mk2"

local hoverCarMK2Recipe = table.deepcopy(data.raw.recipe["car"])
hoverCarMK2Recipe.enabled = false
hoverCarMK2Recipe.icon = "__Hover-Car__/graphics/icons/hover-car-mk2.png"
hoverCarMK2Recipe.icon_size = 128
hoverCarMK2Recipe.name = "hover-car-mk2-recipe"
hoverCarMK2Recipe.energy_required = 16
hoverCarMK2Recipe.order = "b[personal-transport]-a[z]"
hoverCarMK2Recipe.ingredients = {
    {"engine-unit",48},
    {"iron-plate",200},
    {"steel-plate",80},
    {"advanced-circuit",100}
}
hoverCarMK2Recipe.result = "hover-car-mk2-item"

data:extend{

    {
        effects = {
            {
            recipe = "hover-car-mk2-recipe",
            type = "unlock-recipe"
            }
        },
        icon = "__Hover-Car__/graphics/icons/hover-car-mk2.png",
        icon_size = 128,
        name = "hoverCarMK2",
        
        prerequisites = {
            "hoverCar"
        },
        type = "technology",
        unit = {
            count = 250,
            ingredients = {
                {
                    "automation-science-pack",
                    1
                  },
                  {
                    "logistic-science-pack",
                    1
                  },
                  {
                    "chemical-science-pack",
                    1
                  }
            },
            time = 30
       },
    },

    hoverCarMK2,
    hoverCarMK2Item,
    hoverCarMK2Recipe

    
}