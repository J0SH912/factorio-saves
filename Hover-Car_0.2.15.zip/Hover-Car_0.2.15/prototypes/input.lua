data:extend{
    {
        type = "custom-input",
        name = "input_hover-car-exit",
        key_sequence = "",
        linked_game_control = "toggle-driving"
    }
}