require("prototypes.hover-car")
require("prototypes.hover-car-mk2")
require("prototypes.input")

if settings.startup["hover-car-inserter"].value == true then
    data.raw.car["hover-car"].flags = { "placeable-neutral", "player-creation", "not-flammable" }
    data.raw.car["hover-car-mk2"].flags = { "placeable-neutral", "player-creation", "not-flammable" }
end