data:extend({
    {
        type = "bool-setting",
        name = "hover-car-inserter",
        setting_type = "startup",
        default_value = false
    }
})