remote.add_interface("betterCargoPlanes",
		{
			hauler_types = function()
				return { 'better-cargo-plane-0', 'even-better-cargo-plane-0' }
			end
		})