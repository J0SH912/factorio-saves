data:extend({
	{
		type = "bool-setting",
		name = "IslandStart-enabled",
		setting_type = "startup",
		default_value = false,
		order = "a"
	},
	{
		type = "string-setting",
		name = "IslandStart-perimeter-type",
		setting_type = "startup",
		default_value = "Water",
		allowed_values = {"Water", "Wall"},
		order = "b"
	},
	{
		type = "bool-setting",
		name = "IslandStart-place-override",
		setting_type = "startup",
		default_value = false,
		order = "c"
	}
})