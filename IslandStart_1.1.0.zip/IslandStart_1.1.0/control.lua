
function c_area(surface, area, force, x, y, config_perimeter)
	local config_override = settings.startup["IslandStart-place-override"].value
	local tiles = {}
	local t_index = 1
	-- +8 to compensate for the water band's width. (might clip starting resources without this)
	local bastion_radius = math.max(128+8,surface.get_starting_area_radius()-8)
	local b_area = area or {left_top={x=x-bastion_radius, y=y-bastion_radius}, right_bottom={x=x+bastion_radius,y=y+bastion_radius}}
	local inversion = math.max(1.0 - 30.0/bastion_radius, 0.5)
	
	for tx = b_area.left_top.x, b_area.right_bottom.x, 1 do
		for ty = b_area.left_top.y, b_area.right_bottom.y, 1 do
			--simple geometry
			local distance_band = (((tx - x)^2 + (ty - y)^2) / bastion_radius^2)^1.9
			if distance_band > 3.0 then return end
			if inversion < distance_band
				and 1.0 > distance_band
			then
				if config_perimeter == "Water" then
					tiles[t_index] = {name = "deepwater", position = {tx, ty}}
					t_index = t_index + 1
				else
					local ent_name
					if config_perimeter == "Wall" then
						ent_name = "stone-wall"
					else
						ent_name = "gun-turret"
					end
					if config_override or surface.can_place_entity{name = ent_name, position = {tx, ty}} then
						local ent = surface.create_entity{name = ent_name, position = {tx, ty}, force = force}
						-- if ent then
							-- local inv = ent.get_inventory(defines.inventory.turret_ammo)
							-- if inv then
								-- inv.insert{name="firearm-magazine", count = 200}
							-- end
						-- end
					end
				end
			end
		end
	end
	-- log("tiles: " .. tostring(#tiles))
	-- log("radius: " .. tostring(bastion_radius))
	-- log("inversion: " .. tostring(inversion))
	surface.set_tiles(tiles, true)
end

script.on_event(defines.events.on_chunk_generated, function(event)
	if settings.startup["IslandStart-enabled"].value then
		local surface = event.surface
		local config_entity = settings.startup["IslandStart-perimeter-type"].value
		
		for _, force in pairs(game.forces) do
			if #force.players > 0 then
				c_area(surface, event.area, force, force.get_spawn_position(surface).x, force.get_spawn_position(surface).y, config_entity)
			end
		end
	end
	-- for _, positions in ipairs(surface.map_gen_settings.starting_points) do
		-- c_area(positions.x, positions.y, surface, event.area, config_entity)
	-- end
end)
