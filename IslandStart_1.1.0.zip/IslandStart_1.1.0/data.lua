require("IS-noise-programs")

data.raw["map-gen-presets"]["default"]["island-start"] =
    {
      order = "h-[island-start]",
      basic_settings =
      {
        property_expression_names =
        {
          elevation = "IS_0_17-islands+continents",
        },
        autoplace_controls = {},
        terrain_segmentation = 1,
      }
    }
data.raw["map-gen-presets"]["default"]["island-start-scaled"] =
    {
      order = "h-[island-start-scaled]",
      basic_settings =
      {
        property_expression_names =
        {
          elevation = "IS_0_17-islands+continents-scaled",
        },
        autoplace_controls = {},
        terrain_segmentation = 1,
      }
    }
data.raw["map-gen-presets"]["default"]["island-start-ribbon"] =
    {
      order = "i-[island-start-ribbon]",
      basic_settings =
      {
        property_expression_names =
        {
          elevation = "IS_0_17-lakes-elevation-ribbon",
        },
        autoplace_controls = {},
        terrain_segmentation = 1,
      }
    }